<?php

/**
 *
 * @link              frankdevelopers.com
 * @since             1.0.0
 * @package           Actividad_tres
 *
 * @wordpress-plugin
 * Plugin Name:       Actividad3
 * Plugin URI:        actividad_tres
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.0
 * Author:            Eduar Burgos
 * Author URI:        frankdevelopers.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       actividad_tres
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'ACTIVIDAD_TRES_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-actividad_tres-activator.php
 */
function activate_actividad_tres() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-actividad_tres-activator.php';
	Actividad_tres_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-actividad_tres-deactivator.php
 */
function deactivate_actividad_tres() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-actividad_tres-deactivator.php';
	Actividad_tres_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_actividad_tres' );
register_deactivation_hook( __FILE__, 'deactivate_actividad_tres' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-actividad_tres.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_actividad_tres() {

	$plugin = new Actividad_tres();
	$plugin->run();
	

function funcion_campos_actividad3() {
    add_meta_box( 'alumno-metabox', 'Campos de actividad 3', 'campos_personalizados_alumnos', 'post', 'normal', 'high' );
  }
  add_action( 'add_meta_boxes', 'funcion_campos_actividad3' );
  
  function campos_personalizados_alumnos($post) {
    //si existen se recuperan los valores de los metadatos
    $alumno_carrera = get_post_meta( $post->ID, 'alumno_carrera', true );
    $alumno_edad = get_post_meta( $post->ID, 'alumno_edad', true );
    $alumno_peso = get_post_meta( $post->ID, 'alumno_peso', true );
    $alumno_talla = get_post_meta( $post->ID, 'alumno_talla', true );
  
    
    wp_nonce_field( 'alumnos_metabox', 'alumnos_metabox_nonce' );?>
  
    <table width="100%" cellpadding="1" cellspacing="1" border="0">
    <tr>
        <td><strong>Carrera</strong></td>
        <td><input type="text" name="alumno_carrera" value="<?php echo sanitize_text_field($alumno_carrera);?>" class="large-text" placeholder="La Carrera" /></td>
      </tr>
      <tr>
        <td><strong>Edad</strong></td>
        <td><input type="text" name="alumno_edad" value="<?php echo sanitize_text_field($alumno_edad);?>" class="large-text" placeholder="Edad" /></td>
      </tr>
      <tr>
        <td><strong>Peso</strong></td>
        <td><input type="text" name="alumno_peso" value="<?php echo sanitize_text_field($alumno_peso);?>" class="large-text" placeholder="Peso en Kg" /></td>
      </tr>
      <tr>
        <td><strong>Talla</strong></td>
        <td><input type="text" name="alumno_talla" value="<?php echo sanitize_text_field($alumno_talla);?>" class="large-text" placeholder="Talla" /></td>
      </tr>
    </table>
  <?php }
  
  function campos_personalizados_alumnos_save_data($post_id) {
    // Comprobamos si se ha definido el nonce.
    if ( ! isset( $_POST['alumnos_metabox_nonce'] ) ) {
      return $post_id;
    }
    $nonce = $_POST['alumnos_metabox_nonce'];
        
    
    if ( !wp_verify_nonce( $nonce, 'alumnos_metabox' ) ) {
      return $post_id;
    }
  
    
    if ( defined( 'DOING_AUTOSAVE') && DOING_AUTOSAVE ) {
      return $post_id;
    }
    
    // Comprobamos los permisos de usuario.
    if ( $_POST['post_type'] == 'page' ) {
      if ( !current_user_can( 'edit_page', $post_id ) )
        return $post_id;
    } else {
      if ( !current_user_can( 'edit_post', $post_id ) )
        return $post_id;
    }
    
    // Vale, ya es seguro que guardemos los datos.
    
    // Si existen entradas antiguas las recuperamos
    $old_alumno_carrera = get_post_meta( $post_id, 'alumno_carrera', true );
    $old_alumno_edad = get_post_meta( $post_id, 'alumno_edad', true );
    $old_alumno_peso = get_post_meta( $post_id, 'alumno_peso', true );
    $old_alumno_talla = get_post_meta( $post_id, 'alumno_talla', true );
    
 
    $alumno_carrera = sanitize_text_field( $_POST['alumno_carrera'] );
    $alumno_edad = sanitize_text_field( $_POST['alumno_edad'] );
    $alumno_peso = sanitize_text_field( $_POST['alumno_peso'] );
    $alumno_talla = sanitize_text_field( $_POST['alumno_talla'] );
    
    // Actualizamos el campo meta en la base de datos.
    update_post_meta( $post_id, 'alumno_carrera', $alumno_carrera, $old_alumno_carrera );
    update_post_meta( $post_id, 'alumno_edad', $alumno_edad, $old_alumno_edad );
    update_post_meta( $post_id, 'alumno_peso', $alumno_peso, $old_alumno_peso );
    update_post_meta( $post_id, 'alumno_talla', $alumno_talla, $old_alumno_talla );
  }
  add_action( 'save_post', 'campos_personalizados_alumnos_save_data' );
  
  
  //Esta vista publica se debe pasar al directorio público
  
  function funcion_vista_alumno( $content ) {

    $view_alumno_carrera = "";
    $view_alumno_edad = "";
    $view_alumno_peso = "";
    $view_alumno_talla = "";
      $view_alumno_carrera = get_post_meta( get_the_ID(), 'alumno_carrera', true );
      $view_alumno_edad = get_post_meta( get_the_ID(), 'alumno_edad', true );
      $view_alumno_peso = get_post_meta( get_the_ID(), 'alumno_peso', true );
      $view_alumno_talla = get_post_meta( get_the_ID(), 'alumno_talla', true );
      
      if( empty( $view_alumno_carrera && $view_alumno_edad && $view_alumno_peso && $view_alumno_talla ) ) {
          return $content;
      }
  
      $resultado_vista = '
      <h4>Datos del alumno:</h4>
      <p><strong>Carrera:<strong> ' . $view_alumno_carrera . '<br/>
      <p><strong>Edad:<strong> ' . $view_alumno_edad . '<br/>
      <p><strong>Peso:<strong> ' . $view_alumno_peso . '<br/>
      <p><strong>Talla:<strong> ' . $view_alumno_talla . '<br/>';
      return $resultado_vista . $content;
  }
  add_filter( 'the_content', 'funcion_vista_alumno' );



}
run_actividad_tres();
