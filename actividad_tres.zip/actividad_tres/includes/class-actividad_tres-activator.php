<?php

/**
 * Disparado durante la activación del complemento
 *
 * @link       frankdevelopers.com
 * @since      1.0.0
 *
 * @package    Actividad_tres
 * @subpackage Actividad_tres/includes
 */

/**
 * Disparado durante la activación del complemento.
 *
 * Esta clase es necesaria para la activación del plugin
 *
 * @since      1.0.0
 * @package    Actividad_tres
 * @subpackage Actividad_tres/includes
 * @author     Eduar Burgos <frnkdevelopers@gmail.com>
 */
class Actividad_tres_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
