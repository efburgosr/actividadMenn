<?php

/**
 *
 * @link       frankdevelopers.com
 * @since      1.0.0
 *
 * @package    Actividad_tres
 * @subpackage Actividad_tres/includes
 */

/**
 *
 * Esta clase define todo el código necesario para ejecutarse durante la desactivación del complemento.
 *
 * @since      1.0.0
 * @package    Actividad_tres
 * @subpackage Actividad_tres/includes
 * @author     Eduar Burgos <frnkdevelopers@gmail.com>
 */
class Actividad_tres_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
