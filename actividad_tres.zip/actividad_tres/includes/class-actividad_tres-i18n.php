<?php

/**
 *
 * @link       frankdevelopers.com
 * @since      1.0.0
 *
 * @package    Actividad_tres
 * @subpackage Actividad_tres/includes
 */

/**
 *
 * Carga y define los archivos de internacionalización para este complemento
 * para que esté listo para la traducción.
 *
 * @since      1.0.0
 * @package    Actividad_tres
 * @subpackage Actividad_tres/includes
 * @author     Eduar Burgos <frnkdevelopers@gmail.com>
 */
class Actividad_tres_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'actividad_tres',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
