<?php

/**
 *
 * @link       frankdevelopers.com
 * @since      1.0.0
 *
 * @package    Actividad_tres
 * @subpackage Actividad_tres/public/partials
 */
?>

<!-- Este archivo debe consistir principalmente en HTML con un poco de PHP. -->
