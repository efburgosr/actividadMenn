<?php

/**
* Se activa cuando se desinstala el complemento.
  *
  * Al completar este archivo, considere el siguiente flujo
  * de control:
  *
  * - Este método debe ser estático
  * - Compruebe si el contenido de $_REQUEST es realmente el nombre del complemento
  * - Ejecute una verificación de referencia de administrador para asegurarse de que pase por la autenticación
  * - Verifique que la salida de $_GET tenga sentido
  *
 *
 *
 * @link       frankdevelopers.com
 * @since      1.0.0
 *
 * @package    Actividad_tres
 */

// Si no es una llamada a la desistalación de WordPress, entonces exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
