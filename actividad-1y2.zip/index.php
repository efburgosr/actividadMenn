<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="Author" content="Eduar Burgos">
    <title>Formulario actividad 1</title>
</head>
<link rel="stylesheet" href="style.css" media="all" />


<?php

$usuario = $email = $telefono = $password = "";
$usuarioError = "";
$emailError = "";
$telefonoError = "";
$passwordError = "";
$resultado = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $submitValido = true;
    if (empty($_POST["usuario"])) {
        $usuarioError = "Usuario es requerido";
        $submitValido = false;
    } else {
        $usuario = valida_input($_POST["usuario"]);
        // Validar si solo letras
        if (!preg_match("/^[a-zA-Z-']*$/", $usuario)) {
            $usuarioError = "Solo letras para el nombre de usuario";
            $submitValido = false;
        }
    }

    if (empty($_POST["email"])) {
        $emailError = "Email es requerido";
        $submitValido = false;
    } else {
        $email = $_POST["email"];
        $email = filter_var($email, FILTER_SANITIZE_EMAIL);
        //$email = valida_input($_POST["email"]);
        // validar si el email tiene un formato válido
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailError = "Formato de Email inválido";
            $submitValido = false;
        }
    }

    if (empty($_POST["telefono"])) {
        $telefonoError = "El número de telefono es requerido";
        $submitValido = false;
    } else {
        $telefono = valida_input($_POST["telefono"]);
        // validar si el teléfono tiene un formato válido
        if (!preg_match("/^[0-9]+$/", $telefono)) {
            $telefonoError = "Formato de teléfono inválido";
            $submitValido = false;
        }
    }

    if (empty($_POST["password"])) {
        $passwordError = "La contraseña es requerido";
        $submitValido = false;
    } else {
        $password = valida_input($_POST["password"]);
        // validar si la contraseña tiene un formato válido
        if (!preg_match('/^(?=.*\d)(?=.*[A-Za-z])[0-9A-Za-z!@#$%]{8,12}$/', $password)) {
            $passwordError = "La contraseña de tener caracteres especiales, un número, una letra y entre 8 y 20 caracteres de longitud";
            $submitValido = false;
        }
    }

    if ($submitValido) {
        $pCifrada = password_hash($password, PASSWORD_DEFAULT, array("cost" => 10));
        $emailFrom = "noreply@frankdevelopers.com";
        $subject = "mensaje de pruebas de " . $usuario;
        $message = "Mensaje de formularo de actividad 1" . "\r\n\r\n";
        $message .= "El usuario es: " . $usuario . "\r\n";
        $message .= "Email: " . $email . "\r\n";
        $message .= "Teléfono: " . $telefono . "\r\n";
        $message .= "Contraseña cifrada: " . $pCifrada;
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers = 'From:' . $emailFrom . "\r\n"; // Sender's Email
        
        $message = wordwrap($message, 70);
        // Send Mail By PHP Mail Function
        mail("soporte@menntun.com.co, gestion.humana@menntun.com.co, rafael@menntun.com.co", $subject, $message, $headers);
       
        
        //datos para la conexión de la base de datos
        $serveer = 'localhost';
        $Database = 'regiozon_actividad1';
        $user = 'regiozon_activid';
        $password = 'tcs@FYpqX^DG';

        $DB = new PDO("mysql:host=$server; dbname=$Database", $user, $password);

        $DB->exec("SET CHARACTER SET utf8");
        
        
        if ($DB == true) {
        //insert
        $insert = $DB->prepare("INSERT INTO actividad (usuario, telefono, email, password) VALUES (:usuario, :telefono, :email, :password)");
        
        $insert->bindParam(':usuario', $usuario);
        $insert->bindParam(':telefono', $telefono);
        $insert->bindParam(':email', $email);
        $insert->bindParam(':password', $pCifrada);
    
        $insert->execute();
        //cierramos la conexion
        $DB = null;

        $resultado .= "<h4>Recurso de base de datos OK</h4>";
        } else {
            $resultado .= "<h4>no fue posible guardar en BD</h4>";
        }
        $resultado .= "<h4>El correo se ha enviado de forma exitosa</h4>";
    }
}

function valida_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

?>


<body>

    <div class="contenedor">
        <form class="form-horizontal" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <!-- Form Name -->
            <?php echo $resultado; ?>
            <h3 class="titulo3">Formulario actividad 1</h3>
            <!-- Text input-->
            <div class="form-group">
                <label class="col-12 control-label" for="usuario">Usuario</label>
                <div class="col-12">
                    <input id="usuario" name="usuario" type="text" placeholder="ej: usuario" class="input-md" required="">
                    <span class="error"><?php echo $usuarioError; ?></span>
                </div>
            </div>

            <!-- Text input-->
            <div class="form-group">
                <label class="col-12 control-label" for="telefono">Teléfono</label>
                <div class="col-12">
                    <input id="telefono" name="telefono" type="text" placeholder="3xx xxx xxxx" class="input-md" required="">
                    <span class="error"> <?php echo $telefonoError; ?></span>
                </div>
            </div>

            <!-- Password input-->
            <div class="form-group">
                <label class="col-12 control-label" for="email">Email</label>
                <div class="col-12">
                    <input id="email" name="email" type="email" placeholder="tu email" class="input-md" required="">
                    <span class="error"><?php echo $emailError; ?></span>
                </div>
            </div>

            <!-- Password input-->
            <div class="form-group">
                <label class="col-12 control-label" for="password">Contraseña</label>
                <div class="col-12">
                    <input id="password" name="password" type="password" placeholder="Tu Contraseña" class="input-md" required="required">
                    <span class="error"><?php echo $passwordError; ?></span>
                </div>
            </div>

            <!-- Button -->
            <div class="form-group">

                <div class="col-12">
                    <button id="enviar" name="enviar" class="botonEnviar">Enviar</button>
                </div>
            </div>
        </form>
    </div>

</body>

</html>